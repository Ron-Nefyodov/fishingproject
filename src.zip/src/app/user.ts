export class User {
    email:string;
    password: string;
    firstName: string;
    lastName: string;
    token: string;
    current:"active";
	modified: "0";
}
export class Experiment {
    Experiment_id:string;
    name:string;
    manager_id:string;
	template_id:"5c89a19567bf8f3aac54aea5";
    user_ids:string[];
    users:string[];
	last_pos:"0";
}
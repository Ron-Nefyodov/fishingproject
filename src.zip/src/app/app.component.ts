import { Component } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(){}
    

ngOnInit()
  {
    //var opost = new Posts();
    //opost.email = 'arielox01@gmail.com';
    //opost.password ='ani-meleh';

  //  this._DataService.post(opost).

  }
  
  title = 'fishing';
}
